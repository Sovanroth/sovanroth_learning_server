-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: May 31, 2024 at 11:07 AM
-- Server version: 5.7.39
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sovanroth_learning_server`
--

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `id` bigint(20) NOT NULL,
  `commentData` text NOT NULL,
  `createdAt` datetime NOT NULL,
  `courseId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`id`, `commentData`, `createdAt`, `courseId`, `userId`) VALUES
(39, 'Congratulations for purchasing this course! If you have any questions related to this course, please leave a comment. ', '2024-05-04 14:33:16', 2, 1),
(40, 'Congratulations for purchasing this course! If you have any questions related to this course, please leave a comment. ', '2024-05-04 14:33:27', 1, 1),
(41, 'Congratulations for purchasing this course! If you have any questions related to this course, please leave a comment. ', '2024-05-04 14:33:43', 3, 1),
(42, 'Congratulations for purchasing this course! If you have any questions related to this course, please leave a comment. ', '2024-05-04 14:33:51', 4, 1),
(43, 'Congratulations for purchasing this course! If you have any questions related to this course, please leave a comment. ', '2024-05-04 14:34:00', 5, 1);

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `id` bigint(20) NOT NULL,
  `courseTitle` varchar(255) NOT NULL,
  `courseDescription` text NOT NULL,
  `category` int(11) NOT NULL,
  `courseImage` text NOT NULL,
  `coursePrice` varchar(255) NOT NULL,
  `courseResource` text NOT NULL,
  `active` int(11) NOT NULL,
  `createdAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`id`, `courseTitle`, `courseDescription`, `category`, `courseImage`, `coursePrice`, `courseResource`, `active`, `createdAt`) VALUES
(1, 'NestJS Fundamentals Course', 'Nest (NestJS) is a framework for building efficient, scalable Node.js server-side applications. It uses progressive JavaScript, is built with and fully supports TypeScript (yet still enables developers to code in pure JavaScript) and combines elements of OOP (Object Oriented Programming), FP (Functional Programming), and FRP (Functional Reactive Programming).\r\nUnder the hood, Nest makes use of robust HTTP Server frameworks like Express (the default) and optionally can be configured to use Fastify as well!\r\nNest provides a level of abstraction above these common Node.js frameworks (Express/Fastify), but also exposes their APIs directly to the developer. This gives developers the freedom to use the myriad of third-party modules which are available for the underlying platform.', 2, 'https://res.cloudinary.com/drm2qtfij/image/upload/v1714536681/qymtngne5kq2ullkx7zx.webp', '200', 'https://courses.nestjs.com', 1, '2024-05-01 11:11:22'),
(2, 'ReactJS Tutorial for Beginners', 'React is a free and open-source front-end JavaScript library for building user interfaces based on components. It is maintained by Meta and a community of individual developers and companies. React can be used to develop single-page, mobile, or server-rendered applications with frameworks like Next.js.\r\nReact is a free and open-source front-end JavaScript library for building user interfaces based on components. It is maintained by Meta and a community of individual developers and companies. React can be used to develop single-page, mobile, or server-rendered applications with frameworks like Next.js.', 1, 'https://res.cloudinary.com/drm2qtfij/image/upload/v1714799031/b1cefjhjizt179uqp7g6.jpg', '150', 'https://react.dev/', 1, '2024-05-04 12:03:52'),
(3, 'Accounting 101', 'Accountants oversee the financial records of a business and make sure the data is correct. Then, they use this data to create budgets, financial documents, and reports. They can make sure the money coming into the business works with the expenses required to operate. B\r\n\r\nBeyond that, they ensure compliance with the regulatory side of finances.', 3, 'https://res.cloudinary.com/drm2qtfij/image/upload/v1714799361/kr8q5mbi3nqqgmbrnqwd.avif', '100', 'https://blog.hubspot.com/sales/accounting-101', 1, '2024-05-04 12:09:23'),
(4, 'AutoCAD Basic Tutorial for Beginners', 'Many people think you need an Engineering degree to design piped systems such as chemical plants and filtration systems, but that\'s not the case. People are often intimidated by AutoCAD and think it takes years of experience to operate effectively, but this too is a misconception.\r\n\r\nYou are going to walk into this course perhaps never having even SEEN AutoCAD before, and by the end, you\'ll be CONFIDENTLY designing complex, piped systems from scratch. What\'s more, you\'ll be creating virtual, 3D solid models of these systems and then generating all of the drawings necessary to fabricate and assemble your system!\r\n\r\nOnce you learn the material in this course, there really is no limit to what you\'ll be able to design, model and draw.', 4, 'https://res.cloudinary.com/drm2qtfij/image/upload/v1714799608/a7hjoprj4j0itnx9ifdz.avif', '200', 'https://www.autodesk.com/campaigns/autodesk-docs', 1, '2024-05-04 12:13:29'),
(5, 'Complete Filmmaker Guide: Become an Incredible Video Creator', 'Making a movie is an incredibly complex endeavour. These lectures cover the logistics of every aspect of filmmaking breaking down the process into understandable and easy-to-follow sections. Learn about every aspect and department within the production unit and how to best utilize and organize them to create the most inspiring and cost-effective production possible.', 5, 'https://res.cloudinary.com/drm2qtfij/image/upload/v1714799914/aeuz7mg4guhwj80xfg9m.avif', '100', 'https://www.studiobinder.com/film-production-documents/', 1, '2024-05-04 12:18:36');

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE `profile` (
  `id` bigint(20) NOT NULL,
  `profileImage` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`id`, `profileImage`) VALUES
(1, 'https://res.cloudinary.com/drm2qtfij/image/upload/v1714883323/umfkcmjmwgabd12msjoo.jpg'),
(2, 'https://res.cloudinary.com/drm2qtfij/image/upload/v1714657461/vuqxvuoasgzgvkzmsq1o.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `reply`
--

CREATE TABLE `reply` (
  `id` bigint(20) NOT NULL,
  `replyData` text NOT NULL,
  `createdAt` datetime NOT NULL,
  `commentId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `reply`
--

INSERT INTO `reply` (`id`, `replyData`, `createdAt`, `commentId`, `userId`) VALUES
(51, 'Thank you, Bong!', '2024-05-06 06:59:56', 40, 2),
(52, 'Thank you!', '2024-05-06 16:46:14', 42, 1),
(53, 'Thank you!', '2024-05-08 11:22:04', 43, 2);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL,
  `resetToken` varchar(255) DEFAULT NULL,
  `resetTokenExpiration` datetime DEFAULT NULL,
  `profileId` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`, `email`, `createdAt`, `resetToken`, `resetTokenExpiration`, `profileId`) VALUES
(1, 'Eobard Sovanroth', '$2b$10$uzH8kGoilOEKN8JSlzLcFuPEcewI2.A6fml5L8jtqTQ/WD2zLRj9i', 1, 'admin@gmail.com', '2024-05-01 11:07:22', '0ea6b3f7f830848eb7eb5243b0a3613ea8dc5995', '2024-05-08 05:08:54', 1),
(2, 'Sovanroth Nath', '$2b$10$.yEXT988o3st/DzmJ4zHFOeLpcLMSeBtHkEHZdrg5YZNOUFhlIPF.', 0, 'sovanroth016@gmail.com', '2024-05-01 19:57:03', '719532978ecaf6b6ca3912dbce727bab8cc6b8d3', '2024-05-07 06:29:18', 2),
(3, 'lmt', '$2b$10$43k6sjIfaukYS0ykGJoWuOr18o04HmwSxOcvL3PP0uxy6DohMkpMq', 0, 'lmt@gmail.com', '2024-05-06 11:14:43', NULL, NULL, NULL),
(4, 'ADMIN USER', '$2b$10$ndO8stqcJO5pGVQs0XOHnePMqNsmBXmzYtbwPHpVi1aVRHPqa65ea', 0, 'user@gmail.com', '2024-05-07 05:30:37', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users_courses_course`
--

CREATE TABLE `users_courses_course` (
  `usersId` bigint(20) NOT NULL,
  `courseId` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users_courses_course`
--

INSERT INTO `users_courses_course` (`usersId`, `courseId`) VALUES
(1, 1),
(2, 1),
(2, 5);

-- --------------------------------------------------------

--
-- Table structure for table `user_course`
--

CREATE TABLE `user_course` (
  `id` int(11) NOT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `courseId` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `videos`
--

CREATE TABLE `videos` (
  `id` int(11) NOT NULL,
  `video_title` varchar(255) NOT NULL,
  `video_url` varchar(255) NOT NULL,
  `video_description` varchar(255) NOT NULL,
  `video_resource` varchar(255) NOT NULL,
  `courseId` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `videos`
--

INSERT INTO `videos` (`id`, `video_title`, `video_url`, `video_description`, `video_resource`, `courseId`) VALUES
(1, 'Nest.js Crash Course #1 - Introduction & Setup', 'https://youtu.be/pcX97ZrTE6M?si=vQHe6QbbGZK56h3m', '', '', 1),
(2, 'Nest.js Crash Course #2 - Modules', 'https://youtu.be/qZfO4EopfPA?si=Iq0aSTUoqza7Javg', 'In this series you\'ll learn how to make a ninja-themed API with Nest.js, which is a node.js framework for making server side applications.', 'https://youtu.be/qZfO4EopfPA?si=Iq0aSTUoqza7Javg', 1),
(3, 'ReactJS Tutorial - 1 - Introduction', 'https://youtu.be/QFaFIcGhPoM?si=r5BH_SjG139syqYa', '', '', 2),
(4, 'ReactJS Tutorial - 2 - Hello World', 'https://youtu.be/9hb_0TZ_MVI?si=Myo-zhRiftex_g-D', '', '', 2),
(5, 'ReactJS Tutorial - 3 - Folder Structure', 'https://youtu.be/9VIiLJL0H4Y?si=GBgkkQ75z5p2ppuT', '', '', 2),
(6, 'ReactJS Tutorial - 4 - Components', 'https://youtu.be/Y2hgEGPzTZY?si=VMg4r84ahziYJ5v8', '', '', 2),
(7, 'ReactJS Tutorial - 5 - Functional Components', 'https://youtu.be/Cla1WwguArA?si=7nRvQQJfjom6FS6H', '', '', 2),
(8, 'Debits and credits DC ADE LER', 'https://youtu.be/b93KBmcXanI?si=BHQ-IYD0Zs6tE4cy', '', '', 3),
(9, 'Accounting equation explained', 'https://youtu.be/OYql7Y9NnBg?si=VFo4n48cvFamoV5I', '', '', 3),
(10, 'T accounts explained', 'https://youtu.be/f1TDNhuPJLc?si=mt5Ws2d3q2co8pOU', '', '', 3),
(11, 'Debits and credits explained', 'https://youtu.be/n-lCd3TZA8M?si=YBPHQ2MDgMnRr_4G', '', '', 3),
(12, 'AutoCAD Basic Tutorial for Beginners - Part 1 of 3', 'https://youtu.be/cmR9cfWJRUU?si=l_SgkNYGiwUMXT1h', '', '', 4),
(13, 'AutoCAD Basic Tutorial for Beginners - Part 2 of 3', 'https://youtu.be/g_jKTv3pLp0?si=a95cGv3tkeNjTKyJ', '', '', 4),
(14, 'AutoCAD Basic Tutorial for Beginners - Part 3 of 3', 'https://youtu.be/37S-2wZ2r0Q?si=Ognd7dkvJz4NoXXJ', '', '', 4),
(15, 'Source Filmmaker Tutorial Intro', 'https://youtu.be/Ge924trp8B8?si=KPRmzbpyXJE_8st0', '', '', 5),
(16, '01 Interface & Camera controls (SFM Tutorial)', 'https://youtu.be/VP_jWCRgz1U?si=G_FOK0sjffWUZztk', '', '', 5),
(17, '02 Characters & Guide tools (SFM Tutorial)', 'https://youtu.be/zliwdNApgv0?si=nOyH-wnjLMcS6m5K', '', '', 5),
(18, '03 Rigs (SFM Tutorial)', 'https://youtu.be/scarHpHTgdg?si=02nmZtWGN7Qqn-E8', '', '', 5),
(19, '04 Recording & The Clip editor (SFM Tutorial)', 'https://youtu.be/DQKlNfO9hgU?si=5h0UUWOyygUqprB9', '', '', 5),
(20, '05 The Motion editor (SFM Tutorial)', 'https://youtu.be/62EO0Yff3yA?si=TGWH58Z4Q2RKp2GW', '', '', 5);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_a96c50a5a085526d834b734ac4f` (`courseId`),
  ADD KEY `FK_c0354a9a009d3bb45a08655ce3b` (`userId`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `profile`
--
ALTER TABLE `profile`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reply`
--
ALTER TABLE `reply`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_b63950f2876403407137a257a9a` (`commentId`),
  ADD KEY `FK_e9886d6d04a19413a2f0aac5d7b` (`userId`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `IDX_97672ac88f789774dd47f7c8be` (`email`),
  ADD UNIQUE KEY `REL_b1bda35cdb9a2c1b777f5541d8` (`profileId`);

--
-- Indexes for table `users_courses_course`
--
ALTER TABLE `users_courses_course`
  ADD PRIMARY KEY (`usersId`,`courseId`),
  ADD KEY `IDX_e4649aed42456e667716988af6` (`usersId`),
  ADD KEY `IDX_e917312c3c1fb6807e67c95a8f` (`courseId`);

--
-- Indexes for table `user_course`
--
ALTER TABLE `user_course`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_63b2ec4f34c89d4b1219f85a806` (`userId`),
  ADD KEY `FK_67a940b1d7b3cc2f0e99ab6d23b` (`courseId`);

--
-- Indexes for table `videos`
--
ALTER TABLE `videos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_78dfdd8d19fba0a879390340b54` (`courseId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comment`
--
ALTER TABLE `comment`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `profile`
--
ALTER TABLE `profile`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `reply`
--
ALTER TABLE `reply`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user_course`
--
ALTER TABLE `user_course`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `videos`
--
ALTER TABLE `videos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `comment`
--
ALTER TABLE `comment`
  ADD CONSTRAINT `FK_a96c50a5a085526d834b734ac4f` FOREIGN KEY (`courseId`) REFERENCES `course` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_c0354a9a009d3bb45a08655ce3b` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `reply`
--
ALTER TABLE `reply`
  ADD CONSTRAINT `FK_b63950f2876403407137a257a9a` FOREIGN KEY (`commentId`) REFERENCES `comment` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_e9886d6d04a19413a2f0aac5d7b` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `FK_b1bda35cdb9a2c1b777f5541d87` FOREIGN KEY (`profileId`) REFERENCES `profile` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `users_courses_course`
--
ALTER TABLE `users_courses_course`
  ADD CONSTRAINT `FK_e4649aed42456e667716988af62` FOREIGN KEY (`usersId`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_e917312c3c1fb6807e67c95a8f8` FOREIGN KEY (`courseId`) REFERENCES `course` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_course`
--
ALTER TABLE `user_course`
  ADD CONSTRAINT `FK_63b2ec4f34c89d4b1219f85a806` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_67a940b1d7b3cc2f0e99ab6d23b` FOREIGN KEY (`courseId`) REFERENCES `course` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `videos`
--
ALTER TABLE `videos`
  ADD CONSTRAINT `FK_78dfdd8d19fba0a879390340b54` FOREIGN KEY (`courseId`) REFERENCES `course` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
